from ccmixterdl import ccmixterdl

download_song(search="instrumental")