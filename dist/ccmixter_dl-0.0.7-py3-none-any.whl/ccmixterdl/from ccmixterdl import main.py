from ccmixterdl import main

download_song(search="instrumental")